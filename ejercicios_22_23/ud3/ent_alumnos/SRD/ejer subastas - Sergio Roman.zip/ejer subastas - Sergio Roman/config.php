<?php
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'bd_subastas';
    $foroname = 'SUBASTAS SERGIO';

    $moneda = '€';
?>