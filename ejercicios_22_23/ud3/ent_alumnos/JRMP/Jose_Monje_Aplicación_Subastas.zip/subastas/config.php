<?php
// datos BBDD
const DB_HOST = "localhost";
const DB_USER = "root";
const DB_PASS = "";
const DB_DATABASE = "subastas";

// datos aplicación
const CARPETA_IMAGENES = "img";
const FORO_SUBASTAS = "SUBASTAS PACO";
const RUTA_APLICACION = "index.php";
const TIPO_MONEDA = "€";


?>