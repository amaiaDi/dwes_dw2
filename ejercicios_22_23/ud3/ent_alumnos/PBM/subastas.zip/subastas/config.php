<?php

    const DB_HOST="localhost";
    const DB_USER="root";
    const DB_PASS="";
    const DB_DATABASE="subastas";
    const DB_TITULO="SUBASTAS DEWS";
    const DB_RUTA_APP="./";
    const DB_MONEDA="€";
    const DB_RUTA_IMG="imagenes/";

?>